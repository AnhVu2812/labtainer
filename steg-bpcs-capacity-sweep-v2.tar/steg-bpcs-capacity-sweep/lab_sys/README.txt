root lab_sys ok
