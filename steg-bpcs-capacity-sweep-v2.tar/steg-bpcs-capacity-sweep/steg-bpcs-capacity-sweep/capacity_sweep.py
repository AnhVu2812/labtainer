import cv2, csv, numpy as np
VIDEO="input.avi"
BS=8
TH=[0.2,0.3,0.4,0.5]
PLANES=[0,1,2,3]

def alpha(block):
    h,w=block.shape
    k=np.sum(block[:,:-1]!=block[:,1:])+np.sum(block[:-1,:]!=block[1:,:])
    return k/(h*(w-1)+(h-1)*w)

cap=cv2.VideoCapture(VIDEO)
frames=[]
i=0
while len(frames)<20:
    ok,fr=cap.read()
    if not ok: break
    if i%2==0:
        frames.append(cv2.cvtColor(fr,cv2.COLOR_BGR2GRAY))
    i+=1
cap.release()

rows=[]
for p in PLANES:
    vals=[]
    for g in frames:
        plane=((g>>p)&1).astype("uint8")
        H=(plane.shape[0]//BS)*BS
        W=(plane.shape[1]//BS)*BS
        for y in range(0,H,BS):
            for x in range(0,W,BS):
                vals.append(alpha(plane[y:y+BS,x:x+BS]))
    total=len(vals)
    for t in TH:
        nb=sum(v>=t for v in vals)
        rows.append([t,p,total,nb,round(nb/total,4),nb*64,(nb*64)//8])

with open("capacity.csv","w",newline="") as f:
    wr=csv.writer(f)
    wr.writerow(["threshold","bit_plane","total_blocks","noise_blocks","noise_ratio","capacity_bits","capacity_bytes"])
    wr.writerows(rows)

best=max([r for r in rows if r[0]==0.3],key=lambda r:r[5])
open("recommend.txt","w").write(
    f"recommended_alpha={best[0]}\nrecommended_bit_plane={best[1]}\nrecommended_capacity_bits={best[5]}\n"
)
open("summary.txt","w").write("lab=steg-bpcs-capacity-sweep\nmethod=BPCS capacity sweep\n")
open("result.txt","a").write("video_loaded\ncapacity_sweep_done\nlab_done\n")
print("[OK] capacity_sweep_done")
