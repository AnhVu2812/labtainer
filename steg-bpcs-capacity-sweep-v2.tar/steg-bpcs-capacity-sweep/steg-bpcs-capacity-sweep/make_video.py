import cv2, numpy as np
w,h,fps,n=160,120,10,40
rng=np.random.default_rng(2026)
out=cv2.VideoWriter("input.avi",cv2.VideoWriter_fourcc(*"MJPG"),fps,(w,h))
for i in range(n):
    x=np.linspace(0,255,w,dtype=np.uint8)
    base=np.tile(x,(h,1))
    frame=np.zeros((h,w,3),dtype=np.uint8)
    frame[:,:,0]=base
    frame[:,:,1]=np.roll(base,i*3,axis=1)
    frame[:,:,2]=255-base
    cv2.circle(frame,((20+i*4)%w,h//2),16,(255,255,255),-1)
    noise=rng.integers(0,20,(h,w,3),dtype=np.uint8)
    out.write(cv2.add(frame,noise))
out.release()
open("result.txt","a").write("video_created\n")
print("[OK] input.avi created")
