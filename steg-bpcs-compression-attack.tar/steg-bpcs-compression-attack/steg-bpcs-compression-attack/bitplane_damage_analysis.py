import cv2
import numpy as np

print("=== TASK 4: PHÂN TÍCH TỔN THƯƠNG THEO MẶT PHẲNG BIT (BIT-PLANE) ===")

secret_payload = np.load('secret_payload.npy')
embed_indices = [5, 15, 25, 35, 45, 55]
# Lấy file nén chất lượng trung bình làm mẫu phân tích
target_video = "stego_compressed_crf23.mp4"

print(f"[-] Đang phân tích mức độ tàn phá trên video: {target_video}...")

cap = cv2.VideoCapture(target_video)
frame_idx = 0

# Biến đếm lỗi cho từng mặt phẳng bit (0->7)
bp_errors = np.zeros(8, dtype=np.int64)
frames_processed = 0

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break
    
    if frame_idx in embed_indices:
        if len(frame.shape) == 3:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
        for bp in range(8):
            bp_mask = 1 << bp
            orig_bits = (secret_payload & bp_mask) >> bp
            ext_bits = (frame & bp_mask) >> bp
            
            errors = np.sum(orig_bits != ext_bits)
            bp_errors[bp] += errors
            
        frames_processed += 1
    frame_idx += 1
cap.release()

total_pixels_per_bp = secret_payload.size * frames_processed
bp_ber = (bp_errors / total_pixels_per_bp) * 100

print("-" * 55)
print(f"{'Mặt phẳng Bit (Bit-Plane)':<30} | {'BER (%)':<10}")
print("-" * 55)
for bp in range(8):
    plane_name = f"Bit-Plane {bp} (LSB)" if bp == 0 else f"Bit-Plane {bp} (MSB)" if bp == 7 else f"Bit-Plane {bp}"
    print(f"{plane_name:<30} | {bp_ber[bp]:>7.2f}%")
print("-" * 55)

# Lưu mảng lỗi để vẽ đồ thị
np.save('bp_ber_results.npy', bp_ber)
print("[+] Hoàn tất phân tích. Mặt phẳng thấp (LSB) bị xóa sổ mạnh hơn mặt phẳng cao (MSB).\n")
