import subprocess
import os

print("=== TASK 2: TẤN CÔNG NÉN VIDEO BẰNG H.264 (FFMPEG) ===")

input_video = "stego_lossless.avi"

if not os.path.exists(input_video):
    print("[!] LỖI: Không tìm thấy video gốc.")
    exit()

# Kịch bản 1: Nén theo chuẩn CRF (Chất lượng không đổi)
crf_levels = [18, 23, 28, 33, 38] # 18: Gần Lossless, 23: Chuẩn, 38: Rất mờ
print("[-] Đang thực hiện nén H.264 theo các mức CRF...")
for crf in crf_levels:
    output_file = f"stego_compressed_crf{crf}.mp4"
    cmd = [
        "ffmpeg", "-y", "-i", input_video, 
        "-c:v", "libx264", "-preset", "fast", "-crf", str(crf), 
        "-loglevel", "error", output_file
    ]
    subprocess.run(cmd)
    print(f"   + Đã tạo: {output_file}")

# Kịch bản 2: Nén ép Bitrate cực đoan
bitrates = ["1000k", "500k"]
print("\n[-] Đang thực hiện nén ép Bitrate...")
for br in bitrates:
    output_file = f"stego_compressed_{br}bps.mp4"
    cmd = [
        "ffmpeg", "-y", "-i", input_video, 
        "-c:v", "libx264", "-preset", "fast", "-b:v", br, 
        "-loglevel", "error", output_file
    ]
    subprocess.run(cmd)
    print(f"   + Đã tạo: {output_file}")

print("\n[+] Hoàn tất cuộc tấn công nén video.\n")
