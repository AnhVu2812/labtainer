import cv2
import numpy as np
import os

print("=== TASK 1: TẠO VIDEO VÀ NHÚNG TIN BPCS (LOSSLESS) ===")

width, height, fps, frames_count = 640, 480, 30, 60
fourcc = cv2.VideoWriter_fourcc(*'FFV1') # FFV1 là chuẩn nén Lossless hoàn toàn
out = cv2.VideoWriter('stego_lossless.avi', fourcc, fps, (width, height), isColor=False)

# Tạo dữ liệu bí mật ngẫu nhiên (để test sức chịu đựng)
np.random.seed(42)
secret_payload = np.random.randint(0, 2, (height, width), dtype=np.uint8)

print("[-] Đang tạo khung hình và nhúng dữ liệu vào 10% số frame...")
embed_indices = [5, 15, 25, 35, 45, 55] # Khoảng 10% trong 60 frames

for i in range(frames_count):
    # Tạo frame giả lập (gradient + noise)
    frame = np.linspace(0, 255, width, dtype=np.uint8)
    frame = np.tile(frame, (height, 1))
    noise = np.random.randint(0, 50, (height, width), dtype=np.uint8)
    cover_frame = cv2.add(frame, noise)

    if i in embed_indices:
        # Mô phỏng BPCS: Thay thế các mặt phẳng bit bằng payload
        stego_frame = cover_frame.copy()
        for bp in range(8):
            bp_mask = 1 << bp
            # Mô phỏng vùng nhiễu BPCS: Ghi đè bit
            bit_data = (secret_payload & bp_mask)
            stego_frame = (stego_frame & ~bp_mask) | bit_data
            
        # ÉP KIỂU VỀ UINT8 TRƯỚC KHI GHI FRAME ĐỂ TRÁNH LỖI OPENCV
        out.write(stego_frame.astype(np.uint8)) 
    else:
        out.write(cover_frame)

out.release()
# Lưu trữ payload gốc để so sánh BER
np.save('secret_payload.npy', secret_payload)
print("[+] Đã tạo thành công video stego lossless: 'stego_lossless.avi'\n")
