import cv2
import numpy as np
import glob

print("=== TASK 3: TÍNH TOÁN TỶ LỆ LỖI BIT (BER) TỔNG THỂ ===")

secret_payload = np.load('secret_payload.npy')
total_bits = secret_payload.size * 8
embed_indices = [5, 15, 25, 35, 45, 55]

def extract_and_calculate_ber(video_path):
    cap = cv2.VideoCapture(video_path)
    frame_idx = 0
    total_errors = 0
    frames_processed = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret: break
        
        if frame_idx in embed_indices:
            # Video nén H.264 thường trả về BGR, chuyển lại Grayscale
            if len(frame.shape) == 3:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            # Khôi phục toàn bộ 8 mặt phẳng bit
            extracted_data = np.zeros_like(frame)
            for bp in range(8):
                bp_mask = 1 << bp
                extracted_data |= (frame & bp_mask)
            
            # Tính số bit sai lệch
            diff = np.bitwise_xor(secret_payload, extracted_data)
            # Đếm số bit 1 trong biến diff (là số bit lỗi)
            errors = np.sum([((diff >> i) & 1) for i in range(8)])
            total_errors += errors
            frames_processed += 1
            
        frame_idx += 1
        
    cap.release()
    
    if frames_processed == 0: return 100.0
    
    # Tính BER trung bình trên các frame chứa tin
    overall_total_bits = total_bits * frames_processed
    ber = (total_errors / overall_total_bits) * 100
    return ber

video_files = ["stego_lossless.avi"] + sorted(glob.glob("stego_compressed_*.mp4"))

print("-" * 55)
print(f"{'Tên Video':<35} | {'BER (%)':<10}")
print("-" * 55)

for v in video_files:
    ber = extract_and_calculate_ber(v)
    print(f"{v:<35} | {ber:>7.2f}%")

print("-" * 55)
print("[!] NHẬN XÉT: Nén H.264 đã phá hủy gần như toàn bộ dữ liệu (BER xấp xỉ 50% - bằng đoán mò).\n")
