import numpy as np
import matplotlib.pyplot as plt

print("=== TASK 5: TRỰC QUAN HÓA SỰ SỤP ĐỔ CỦA BPCS TRÊN VIDEO ===")

try:
    bp_ber = np.load('bp_ber_results.npy')
except FileNotFoundError:
    print("[!] LỖI: Chạy 04_bitplane_damage_analysis.py trước.")
    exit()

bit_planes = np.arange(8)
labels = ['BP0 (LSB)', 'BP1', 'BP2', 'BP3', 'BP4', 'BP5', 'BP6', 'BP7 (MSB)']

plt.figure(figsize=(10, 6))

# Vẽ biểu đồ cột thể hiện mức độ lỗi của từng Bit-plane
bars = plt.bar(bit_planes, bp_ber, color='tomato', edgecolor='black')

plt.title("Phân tích tổn thương BPCS sau khi nén H.264 (CRF=23)", fontsize=14)
plt.xlabel("Mặt phẳng Bit", fontsize=12)
plt.ylabel("Tỷ lệ lỗi bit BER (%)", fontsize=12)
plt.xticks(bit_planes, labels)
plt.ylim(0, 60)
plt.axhline(y=50, color='r', linestyle='--', linewidth=1.5, label='Ngưỡng phá hủy hoàn toàn (50%)')

# Đánh nhãn giá trị trên đầu cột
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 1, f'{yval:.1f}%', ha='center', va='bottom', fontweight='bold')

plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

plt.savefig('bpcs_bitplane_damage.png', dpi=300)
print("[+] Đã xuất đồ thị tại 'bpcs_bitplane_damage.png'.")
print("✅ Hoàn thành Lab 1 chuyên đề Video BPCS!\n")
