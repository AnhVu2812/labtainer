import cv2
import numpy as np

BLOCK_SIZE = None
THRESHOLD = None

def calculate_complexity(block):
	# TODO
	pass

def classify_block(ciomplexity):
	# TODO
	pass

img = cv2.imread("input.png", 0)

for bit in range(8):
	plane = ((img >> bit) & 1).astype(np.unit8)

	h, w = plane.shape

	for y in range(0, h, BLOCK_SIZE):
		for x in range(0, w, BLOCK_SIZE):
			block = plane[y:y+BLOCK_SIZE, x:x+BLOCK_SIZE]

			if block.shape != (BLOCK_SIZE, BLOCK_SIZE):
				continue
			c = calculate_complexity(block)
			if classify_block(c):
				pass

print("Analysis completed")
