import cv2
from PIL import Image

img = Image.open("frames/frame_001.png").convert("RGB")

qr = Image.open("secret_qr.png").convert("1")

img_pixels = img.load()
qr_pixels = qr.load()

width, height = qr.size

for y in range(height):
	for x in range(width):
		qr_bit = 0 if qr_pixels[x, y] == 0 else 1
		pixel = list(img_pixels[x, y])

		pixel[0] = (pixel[0] & ~1) | qr_bit

		img_pixels[x, y] = tuple(pixel)

img.save("frames/frame_001.png")
print("QR embedded successfully")
