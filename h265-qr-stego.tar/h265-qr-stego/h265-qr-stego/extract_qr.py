from PIL import Image
from pyzbar.pyzbar import decode

img = Image.open("frames/frame_001.png").convert("RGB")

pixels = img.load()

width, height = img.size

qr = Image.new("1", (200,200))
qr_pixels = qr.load()

for y in range(200):
	for x in range(200):
		bit = pixels[x, y][0] & 1

		qr_pixels[x, y] = 255 if bit else 0
qr.save("recovered_qr.png")

decoded = decode(qr)

if decoded:
	print("QR detected:")
	print(decoded[0].data.decode())
else:
	print("No QR detected")

