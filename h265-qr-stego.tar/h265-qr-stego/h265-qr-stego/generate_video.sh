#!/bin/bash

ffmpeg -f lavfi -i testsrc=size=1280x720:rate=30 -t 10 sample.mp4
