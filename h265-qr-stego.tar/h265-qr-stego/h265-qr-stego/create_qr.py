import qrcode

data = "Secret message detected"

img = qrcode.make(data)

img.save("secret_qr.png")

print("QR created")
