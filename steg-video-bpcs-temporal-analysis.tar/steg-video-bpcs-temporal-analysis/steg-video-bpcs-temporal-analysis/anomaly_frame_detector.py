import numpy as np

print("=== TASK 4: THUẬT TOÁN PHÁT HIỆN DỊ THƯỜNG (ANOMALY DETECTION) ===")

delta_alpha = np.load('delta_alpha.npy')
mean_delta = np.mean(delta_alpha)
std_delta = np.std(delta_alpha)

# Thiết lập ngưỡng phát hiện (Threshold): Z-score > 2.0 (Vượt qua 2 lần độ lệch chuẩn)
z_threshold = 2.0
threshold_value = mean_delta + (z_threshold * std_delta)

print(f"[-] Đang thiết lập Ngưỡng cảnh báo (Threshold) = {threshold_value:.6f}")
print("[-] Đang rà quét chuỗi thời gian...\n")

detected_frames = []

# Mảng delta_alpha có chiều dài N-1, nên index i tương ứng với sự thay đổi giữa frame i và i+1
for i, diff in enumerate(delta_alpha):
    if diff > threshold_value:
        # Cảnh báo frame i+1 vì nó gây ra sự thay đổi đột ngột so với frame i
        suspect_frame = i + 1
        detected_frames.append(suspect_frame)
        print(f"🚨 [CẢNH BÁO MỨC CAO] Phát hiện bất thường tại Frame: {suspect_frame} | Delta = {diff:.4f}")

# Gom nhóm các frame liên tiếp để đưa ra kết luận
print("\n[+] KẾT LUẬN CỦA HỆ THỐNG STEGANALYSIS:")
if len(detected_frames) > 0:
    print(f"-> Thuật toán phát hiện {len(detected_frames)} khung hình có dấu hiệu bị thao túng dữ liệu (BPCS Steganography).")
    print(f"-> Danh sách Frame nghi ngờ: {detected_frames}")
else:
    print("-> Video sạch, không phát hiện sự bất đồng bộ thời gian.")
print("")
