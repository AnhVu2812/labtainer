import cv2
import numpy as np

print("=== TASK 2: TRÍCH XUẤT CHUỖI THỜI GIAN ĐỘ PHỨC TẠP ALPHA ===")

video_path = 'suspect_video.avi'
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("[!] LỖI: Không tìm thấy video.")
    exit()

alpha_series = []
frame_idx = 0

print("[-] Đang quét video và tính toán Black-White borders bằng thuật toán Matrix...")
while True:
    ret, frame = cap.read()
    if not ret: break
    
    if len(frame.shape) == 3:
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
    # Lấy mặt phẳng LSB (Bit-plane 0)
    bp0 = frame & 1
    
    # THUẬT TOÁN TÍNH NHANH BORDER (Không dùng vòng lặp for tốn thời gian)
    # Tính khác biệt theo chiều ngang (Dịch cột)
    diff_h = np.sum(bp0[:, 1:] != bp0[:, :-1])
    # Tính khác biệt theo chiều dọc (Dịch hàng)
    diff_v = np.sum(bp0[1:, :] != bp0[:-1, :])
    
    total_borders = diff_h + diff_v
    
    # Tính số border tối đa có thể có của ảnh WxH
    h, w = bp0.shape
    max_borders = (w - 1) * h + (h - 1) * w
    
    # Tính độ phức tạp alpha của toàn frame
    alpha = total_borders / max_borders
    alpha_series.append(alpha)
    frame_idx += 1

cap.release()

# Lưu thành mảng Numpy để phân tích
np.save('alpha_series.npy', np.array(alpha_series))
print(f"[+] Đã trích xuất xong đặc trưng của {frame_idx} frames.")
print("[+] Dữ liệu được lưu tại 'alpha_series.npy'\n")
