import cv2
import numpy as np

print("=== TASK 1: KHỞI TẠO VIDEO VÀ NHÚNG TIN GIÁN ĐOẠN ===")

width, height, frames_count = 640, 480, 60
fourcc = cv2.VideoWriter_fourcc(*'FFV1')
out = cv2.VideoWriter('suspect_video.avi', fourcc, 30, (width, height), isColor=False)

# Các frame kẻ tấn công chọn để giấu tin
stego_frames = [15, 16, 17, 42, 43, 44] 
np.random.seed(99)

print("[-] Đang tạo video với vật thể chuyển động (để alpha biến thiên tự nhiên)...")
for i in range(frames_count):
    # Tạo nền xám chuyển động mượt
    frame = np.ones((height, width), dtype=np.uint8) * 100
    # Vẽ một hình tròn di chuyển từ trái sang phải để tạo biến thiên thời gian
    pos_x = int((i / frames_count) * width)
    cv2.circle(frame, (pos_x, height//2), 80, 150, -1)
    
    # Thêm chút nhiễu nền tự nhiên
    natural_noise = np.random.randint(0, 10, (height, width), dtype=np.uint8)
    cover_frame = cv2.add(frame, natural_noise)

    if i in stego_frames:
        # Kẻ tấn công lén nhúng dữ liệu ngẫu nhiên vào Mặt phẳng Bit 0 (LSB)
        payload = np.random.randint(0, 2, (height, width), dtype=np.uint8)
        stego_frame = (cover_frame & ~1) | payload
        out.write(stego_frame.astype(np.uint8))
    else:
        out.write(cover_frame)

out.release()
print(f"[+] Đã sinh video 'suspect_video.avi'.")
print(f"[+] Kẻ tấn công đã giấu tin vào các frame: {stego_frames}\n")
