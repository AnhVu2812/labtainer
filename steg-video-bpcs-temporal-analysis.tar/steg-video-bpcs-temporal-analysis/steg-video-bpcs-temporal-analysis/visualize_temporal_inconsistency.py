import numpy as np
import matplotlib.pyplot as plt

print("=== TASK 5: TRỰC QUAN HÓA BẰNG CHỨNG PHÁP Y (FORENSICS PLOT) ===")

alpha_series = np.load('alpha_series.npy')
delta_alpha = np.load('delta_alpha.npy')
mean_delta = np.mean(delta_alpha)
std_delta = np.std(delta_alpha)
threshold_value = mean_delta + (2.0 * std_delta)

frames = np.arange(len(alpha_series))
frames_diff = np.arange(1, len(alpha_series))

plt.figure(figsize=(12, 8))

# Đồ thị 1: Sự biến thiên của Độ phức tạp Alpha
plt.subplot(2, 1, 1)
plt.plot(frames, alpha_series, marker='o', markersize=4, linestyle='-', color='blue', label='Complexity (Alpha)')
plt.title("Đồ thị 1: Độ phức tạp mặt phẳng bit 0 (LSB) theo thời gian", fontsize=14)
plt.ylabel("Giá trị Alpha")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

# Đồ thị 2: Đạo hàm bậc 1 (Sự chênh lệch giữa các frame)
plt.subplot(2, 1, 2)
plt.plot(frames_diff, delta_alpha, linestyle='-', color='gray', label='Delta Alpha (Mức độ thay đổi)')

# Đánh dấu các điểm vượt ngưỡng
anomalies_x = []
anomalies_y = []
for i, diff in enumerate(delta_alpha):
    if diff > threshold_value:
        anomalies_x.append(i + 1)
        anomalies_y.append(diff)

plt.scatter(anomalies_x, anomalies_y, color='red', s=100, zorder=5, label='Bất thường (Stego-Frames)')
plt.axhline(y=threshold_value, color='orange', linestyle='--', linewidth=2, label='Ngưỡng phát hiện (Threshold)')

plt.title("Đồ thị 2: Phát hiện dị thường (Temporal Inconsistency)", fontsize=14)
plt.xlabel("Chỉ số Khung hình (Frame Index)")
plt.ylabel("Mức độ chênh lệch (Delta)")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

plt.tight_layout()
plt.savefig('temporal_steganalysis.png', dpi=300)
print("[+] Đã xuất đồ thị tại 'temporal_steganalysis.png'.")
print("✅ Hoàn thành phân tích pháp y chuỗi thời gian!\n")
