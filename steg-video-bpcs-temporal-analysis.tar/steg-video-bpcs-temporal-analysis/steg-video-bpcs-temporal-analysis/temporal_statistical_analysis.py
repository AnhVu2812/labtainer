import numpy as np

print("=== TASK 3: PHÂN TÍCH THỐNG KÊ VÀ TÍNH VARIANCE ===")

try:
    alpha_series = np.load('alpha_series.npy')
except FileNotFoundError:
    print("[!] LỖI: Vui lòng chạy Task 2 trước.")
    exit()

# Tính đạo hàm bậc 1: delta_alpha = |alpha(t) - alpha(t-1)|
delta_alpha = np.abs(np.diff(alpha_series))

# Tính các đại lượng thống kê trên chuỗi delta_alpha
mean_delta = np.mean(delta_alpha)
var_delta = np.var(delta_alpha)
std_delta = np.std(delta_alpha)

print(f"[-] Thông số thống kê của sự biến thiên giữa các Frame (Delta Alpha):")
print(f"    + Giá trị trung bình (Mean)   : {mean_delta:.6f}")
print(f"    + Phương sai (Variance)       : {var_delta:.6f}")
print(f"    + Độ lệch chuẩn (Std Dev)     : {std_delta:.6f}")

# Lưu delta_alpha để dùng cho bước sau
np.save('delta_alpha.npy', delta_alpha)

print("\n[!] GHI CHÚ: Phương sai lớn chứng tỏ video có sự giật cục về mặt cấu trúc dữ liệu.")
print("[+] Chuyển sang Task 4 để dò tìm frame bất thường!\n")
